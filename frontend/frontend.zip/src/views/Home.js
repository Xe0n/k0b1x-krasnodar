import { useState, useEffect } from 'react'
import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  CardText,
  CardLink,
} from "reactstrap";
import FileUploaderSingle from './fileUploader/index'
import DataTablesBasic from './table/DataTableBasic'
import axios from 'axios'
import serverDown from '../assets/images/office-server.gif'
// ** Styles
import '@styles/react/libs/tables/react-dataTable-component.scss'

const Home = () => {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(false)
  const [errorAxios, setErorrAxios] = useState('')

  const getData = async () => {
      setLoading(false)
      const response = await axios.get(
        `https://675c-188-0-169-150.eu.ngrok.io/analyse/?skip=0&limit=100`
      ).catch(function (error) {
        console.log(`Ошибка обращения к API ${error.message}`)
        setErorrAxios(error.message)
      })
  
      setData(response.data)
      setLoading(false)
      console.log(response)
    }
    useEffect(() => {
      setLoading(true)
      getData()
    }, [])
    console.log(errorAxios)
  if (errorAxios !== 'Network Error'){
    return (
      <div>
        <Card>
          <CardHeader>
            <CardTitle>Загрузите ваш файл для начала работы 🚀</CardTitle>
          </CardHeader>
          <CardBody>
            <CardText>Мы ожидаем от вас формат .parquet</CardText>
            <FileUploaderSingle getData={getData}/>
          </CardBody>
        </Card>
        <Card>
          <DataTablesBasic getData={getData} data={data}/>
        </Card>
  
  
      </div>
    );
  } else {
    return (
    <>
      <Card>
          <CardHeader>
            <CardTitle>Ошибка обращения к серверу =(</CardTitle>
          </CardHeader>
          <CardBody>
              <h5>Похоже снегурочка выдернула компьютер с бэком из розетки, если вы хотели посмотреть на работу сервиса пожалуйста свяжитесь с нами и мы все починим:</h5>
              <ul>
                <li><a href="https://t.me/gesitnikov">@gesitnikov</a></li>
                <li><a href="https://t.me/TakhUsam">@TakhUsam</a></li>
                <li><a href="https://t.me/artrsv">@artrsv</a></li>
                <li><a href="https://t.me/Kmondzy">@Kmondzy</a></li>
              </ul>
              <div>
                <img src={serverDown} alt="" />
              </div>
          </CardBody>
        </Card>
    </>
    )
  }
  
};

export default Home;
