import { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'

import {
  Card,
  CardHeader,
  CardBody,
  CardTitle,
  CardText,
  CardLink,
  Row,
  Col,
  Table,
  Badge
} from "reactstrap";
import FileUploaderSingle from './fileUploader/index'
import DataTablesSingle from './table/DataTableSingle'
import axios from 'axios'

import ApexRadial from './charts/ApexRadial'
import ApexBarChart from './charts/ApexBar'
import StatsCard from './charts/StatCard';
import ApexHeatmapChart from './charts/HeatMap'

// ** Styles
import '@styles/react/libs/tables/react-dataTable-component.scss'

const Analyse = () => {
  const [data, setData] = useState([])
  const [loading, setLoading] = useState(false)
  const [popularRoute, setPopularRoutes] = useState([])
  const [popularShippers, setPopularShippers] = useState([])
  const [topDistinations, setTopDisitinations] = useState([])
  const [topPostSenders, setTopPostSenders] = useState([])
  const { itemId } = useParams()

  const getData = async (id) => {
      
      setLoading(true)
      const response = await axios.get(
        `https://675c-188-0-169-150.eu.ngrok.io/analyse/${id}`
      )
  
      setData([response.data])
      setLoading(false)
      
      console.log(response)
    }
    useEffect(() => {
      getData(itemId)
    }, [])
    useEffect(() => {
      data[0]?.top_routes !== undefined ? setPopularRoutes(JSON.parse(data[0]?.top_routes)) : ''
      data[0]?.top_shippers !== undefined ? setPopularShippers(JSON.parse(data[0]?.top_shippers)) : ''
      data[0]?.top_post_destinations !== undefined ? setTopDisitinations(JSON.parse(data[0]?.top_post_destinations)) : ''
      data[0]?.top_post_senders !== undefined ? setTopPostSenders(JSON.parse(data[0]?.top_post_senders)) : ''
    }, [data])
    
// console.log(data[0]?.departure_load)
  return (
    <div>
      <Card>
        <DataTablesSingle getData={getData} data={data}/>
      </Card>
                {!loading ?
                <>
                <Row className='match-height'>
                    <Col sm={12}>
                      <StatsCard dataset={[data[0]?.empty_carriages, data[0]?.loaded_carriages, popularRoute.slice(0,1)]} cols={{ xl: '3', sm: '6' }}/>
                    </Col>
                </Row>
                
                <Row className='match-height mt-2'>
              
                    <Col md={6} sm={12}>
                      <ApexBarChart data={topDistinations.slice(0,10)} title="Самые нагруженные станции получения" type={true} info='#8A2432'/>
                    </Col>
                    <Col md={6} sm={12}>
                      <ApexBarChart data={topPostSenders.slice(0,10)} title="Самые нагруженные станции отправления" type={false} info='#8A2432'/>
                    </Col>
                    <Col md={6} sm={12}>
                    
                      <Card className='p-1'>
                          <h4 className='card-title'>Топ маршрутов</h4>
                          <Table responsive >
                              
                              <thead>
                                  <tr>
                                      <th>Маршрут</th>
                                      <th>Кол-во перевозок</th>
                                  </tr>
                              </thead>
                              <tbody>
                                {popularRoute.slice(0,10).sort((a, b) => a.count < b.count ? 1 : -1).map((item, index) => (
                                  <>
                                  <tr key={item.name}>
                                      <td>{item.name}</td>
                                      <td><Badge>{item.count}</Badge></td>
                                  </tr>
                                  </>
                                ))}
                                  
                              </tbody>
                          </Table>
                        </Card>
                    </Col>
                    <Col md={6} sm={12}>
                    
                    <Card className='p-1'>
                        <h4 className='card-title'>Топ компаний</h4>
                        <Table responsive >
                            
                            <thead>
                                <tr>
                                    <th>Компания</th>
                                    <th>Кол-во перевозок</th>
                                </tr>
                            </thead>
                            <tbody>
                              {popularShippers.slice(0,10).sort((a, b) => a.count < b.count ? 1 : -1).map((item, index) => (
                                <>
                                <tr key={item.name}>
                                    <td>{item.name}</td>
                                    <td><Badge>{item.count}</Badge></td>
                                </tr>
                                </>
                              ))}
                                
                            </tbody>
                        </Table>
                      </Card>
                  </Col>
                  <Col sm={12} md={12}>
                    <ApexHeatmapChart />
                  </Col>
                </Row>
                </>
                : 'Загрузка данных'}



    </div>
  );
};

export default Analyse;
