import { useState, useEffect } from 'react'

// ** Third Party Components
import { ChevronDown } from 'react-feather'
import DataTable from 'react-data-table-component'
import { Link } from 'react-router-dom'
import ReactPaginate from 'react-paginate'

// ** Reactstrap Imports
import { Button, Card, CardHeader, CardTitle } from 'reactstrap'
// const data = [{
//     id: 1,
//     date: '2022-03-12',
//     status: 'Готово'
// }]

const DataTablesBasic = ({getData, data}) => {
    const [currentPage, setCurrentPage] = useState(0)
    const [searchValue, setSearchValue] = useState('')
    const [filteredData, setFilteredData] = useState([])
    const basicColumns = [
        {
            id: 'id',
            name: 'ID',
            sortable: true,
            selector: row => row.id
        },
        {
            name: 'Дата загрузки',
            sortable: true,
            selector: row => row.created_at
        },
        {
            name: 'Действие',
            selector: row => row.id,
            cell: row => {
                return (
                    <>
                    <Link to={`/analyse/${row.id}`}>
                        <Button className='my-1'>Открыть статистику</Button>
                    </Link>    
                    </> 
                )}
        },
        {
            name: 'Файл',
            selector: row => row.id,
            cell: row => {
                return (
                    <a href={`https://675c-188-0-169-150.eu.ngrok.io/${row.output_file.path}`} target="_blank">
                        <Button className='my-1'>Скачать {row.output_file.filename}</Button>
                    </a> 
                )
            }
        }
    ]
  const handlePagination = page => {
    setCurrentPage(page.selected)
  }
      // ** Custom Pagination
  const CustomPagination = () => (
    <ReactPaginate
      previousLabel=''
      nextLabel=''
      forcePage={currentPage}
      onPageChange={page => handlePagination(page)}
      pageCount={searchValue.length ? Math.ceil(filteredData.length / 7) : Math.ceil(data.length / 7) || 1}
      breakLabel='...'
      pageRangeDisplayed={2}
      marginPagesDisplayed={2}
      activeClassName='active'
      pageClassName='page-item'
      breakClassName='page-item'
      nextLinkClassName='page-link'
      pageLinkClassName='page-link'
      breakLinkClassName='page-link'
      previousLinkClassName='page-link'
      nextClassName='page-item next-item'
      previousClassName='page-item prev-item'
      containerClassName='pagination react-paginate separated-pagination pagination-sm justify-content-end pe-1 mt-1'
    />
  )
  return (
    <Card className='overflow-hidden'>
      <CardHeader>
        <CardTitle tag='h4'>Предыдущие записи</CardTitle>
      </CardHeader>
      <div className='react-dataTable'>
        <DataTable
          noHeader
          pagination
          defaultSortFieldId="id"
          defaultSortAsc={false}
          data={data}
          columns={basicColumns}
          className='react-dataTable'
          sortIcon={<ChevronDown size={10} />}
          paginationComponent={CustomPagination}
          paginationDefaultPage={currentPage + 1}
          paginationRowsPerPageOptions={[10, 25, 50, 100]}
        />
      </div>
    </Card>
  )
}

export default DataTablesBasic
