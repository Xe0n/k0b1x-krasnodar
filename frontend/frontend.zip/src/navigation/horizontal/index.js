import { Mail, Home, Send } from "react-feather";

export default [
  {
    id: "home",
    title: "Главная",
    icon: <Home size={20} />,
    navLink: "/home",
  },
  {
    id: "retrain",
    title: "Переобучение модели",
    icon: <Send size={20} />,
    navLink: "/retrain",
  }
];
